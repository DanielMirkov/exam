All tests passed with me besides the test for search for some reason
It could be something I am missing but the App was working on my end as it was required